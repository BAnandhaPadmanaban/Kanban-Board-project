package com.niit.project.userauthenticationservice.services;

import com.niit.project.userauthenticationservice.domain.UserDetails;
import com.niit.project.userauthenticationservice.exception.UserAlreadyExistsException;
import com.niit.project.userauthenticationservice.exception.UserLoginException;

public interface IUserService {

    //register method
    UserDetails registerUser(UserDetails user)throws UserAlreadyExistsException;

    //login method
    UserDetails loginUser(UserDetails user)throws UserLoginException;

    //updatePassword method
    UserDetails updatePassword(UserDetails user)throws  UserLoginException ;
}
