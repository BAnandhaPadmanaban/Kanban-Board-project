package com.niit.project.userauthenticationservice.exception;

public class UserLoginException extends RuntimeException{
    public UserLoginException(String message){
        super(message);
    }
}
