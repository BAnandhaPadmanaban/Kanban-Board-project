package com.niit.project.userauthenticationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
