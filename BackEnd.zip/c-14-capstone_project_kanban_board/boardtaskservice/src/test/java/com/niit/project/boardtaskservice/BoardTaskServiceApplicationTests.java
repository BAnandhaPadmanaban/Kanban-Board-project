package com.niit.project.boardtaskservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardTaskServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
