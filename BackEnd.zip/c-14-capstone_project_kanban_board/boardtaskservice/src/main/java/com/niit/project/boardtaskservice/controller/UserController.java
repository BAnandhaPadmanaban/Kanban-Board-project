package com.niit.project.boardtaskservice.controller;

import com.niit.project.boardtaskservice.services.IUserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController

@RequestMapping("/api/v3")
public class UserController {
    private final IUserService userService;

    @Autowired
    public UserController(IUserService userService) {
        this.userService = userService;
    }
    @GetMapping("/getOneTask/{taskId}")
    public ResponseEntity<?> getOneTaskById(@PathVariable int taskId, HttpServletRequest request) {
        ResponseEntity responseEntity;
        try {
            String userId = getCustomerIdFromClaims(request);
            responseEntity = new ResponseEntity<>(userService.getOneTaskById(taskId,userId), HttpStatus.ACCEPTED);
        } catch (Exception e) {
            responseEntity = new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }return responseEntity;
    }
    @GetMapping("/getAllTask")
    public ResponseEntity<?> getAllTaskFromUser(HttpServletRequest request) {
        ResponseEntity responseEntity;
        try {
            String userId = getCustomerIdFromClaims(request);
            responseEntity = new ResponseEntity<>(userService.getAllTaskFromUser(userId), HttpStatus.ACCEPTED);
        } catch (Exception e) {
            responseEntity = new ResponseEntity<>(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }return responseEntity;
    }



    private String getCustomerIdFromClaims(HttpServletRequest request) {
        String userId=request.getAttribute("emailId").toString();
        return userId;
    }

}
