export type user={
    emailId:String ,
    userName:String,
    password:String,
     role:String;
     taskslist: undefined
}