export type Task={
     taskId?:number
     taskName?:string
     taskDescription?:string
     dueDate?:string
     assignTo?:string
     status?:string
}