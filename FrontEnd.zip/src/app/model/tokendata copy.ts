// export type tokenDetails=
//     {
//         UserDetails: [{
//             emailId: string;
//             role: string;
//             password: string;
//         }];
//         message: string;
//         token: string;
// }