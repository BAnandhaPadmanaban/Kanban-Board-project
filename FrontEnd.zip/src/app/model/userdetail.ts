// export type userDetails={
//     emailId:string,
//     password:string
   
// }