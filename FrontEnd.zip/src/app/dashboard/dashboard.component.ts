import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CdkDragDrop, moveItemInArray, transferArrayItem } from '@angular/cdk/drag-drop';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { Task } from '../model/task';
import { ToastrService } from 'ngx-toastr';
import { MatDialog } from '@angular/material/dialog';
// import { LogincheckService } from '../loginService/logincheck.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  taskData: Array<any> = [];
  allUsersData:Array<any> = [];
  currentTask: any;
  userName='';
  UserRole='';
  sessionMail:any=sessionStorage.getItem('userEmail')



  constructor(public dialog: MatDialog,private userService:UserService,private toastr:ToastrService,private router:Router) {}

  ngOnInit() {
    this.refreshTask();
    this.allusers();

    console.log(this.sessionMail);
    this.userService.getUserName().subscribe((resp)=>{
      this.userName=resp;
      console.log(resp);
    });

    this.userService.getUserRole().subscribe((resp)=>{
      this.UserRole=resp;
      console.log(resp);
    });
  }

  // Color based on priority
  getBackgroundColor(priority: string): string {
    switch (priority) {
      case 'Low':
        return 'lightgreen';
      case 'Medium':
        return 'coral';
      case 'High':
        return 'lightcoral';
      default:
        return 'coral';
    }
  }

  refreshTask() {
    this.userService. getAllTask().subscribe((taskData: any) => {
      this.taskData = taskData;
      console.log(taskData);
    });
  }

  // Count Number of tasks
  getTasksCount(column: string): number {
    const filteredTasks = this.filterTasks(column);
    return filteredTasks ? filteredTasks.length : 0;
  }

  // filter the task data (By status)
  filterTasks(status: string) {
    return this.taskData?.filter((m) => m.status == status);
  }

  
  // Filter the task data for all users (By status)
  filterAllUserTasks(status: string) {
    return this.allUsersData?.filter((c) => c.status == status);
  }


  

  onDragStart(task: any) {
    this.currentTask = task;
  }

  // Drag and Drop
  onDrop($event: any, status: string) {
    if(this.UserRole == 'Admin'){
      const updatedStatus = this.taskData.find((m) => m.taskId == this.currentTask.taskId);
      if (updatedStatus != undefined) {
        updatedStatus.status = status;
        this.userService.updateTask(updatedStatus).subscribe(
          (response) => {
             console.log('Status updated successfully', response);
            this.toastr.success("Tasked Moved Successfully");
        }
      )}
      // this.currentTask = null;
    }

    if(this.UserRole == 'user'){
      const updatedStatus = this.allUsersData.find((m) => m.taskId == this.currentTask.taskId);
      if (updatedStatus != undefined) {
        updatedStatus.status = status;
        this.userService.updateTask(updatedStatus).subscribe(
          (response) => {
             console.log('Status updated successfully', response);
            this.toastr.success("Tasked Moved Successfully");
        }
      )}
      // this.currentTask = null;
    }
  }

  onDragOver(event: any) {
    event.preventDefault();
  }
  allusers(){
    this.userService.getAllUsers().subscribe((allUsersData:any)=>{
      this.allUsersData=allUsersData[0].taskList;
      console.log(this.allUsersData);
    })
  }


   // navigate-to-add-task
  addTask(){
      this.router.navigateByUrl("addtask")
  }

}
